let hours_worked = [11;11;11]
