let hours_worked = [22;22;22]
