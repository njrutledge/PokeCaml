open Item
type t = (Item.t * int) list